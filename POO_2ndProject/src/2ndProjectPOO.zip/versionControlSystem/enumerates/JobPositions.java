package versionControlSystem.enumerates;

/**
 * @author Lucas Girotto / Pedro Afonso
 * <p>
 * Enumerate for job positions
 */
public enum JobPositions {
    DEVELOPER, MANAGER,
}
