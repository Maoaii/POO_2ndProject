package versionControlSystem.enumerates;

/**
 * @author Lucas Girotto / Pedro Afonso
 * <p>
 * Enumerate for project types
 */
public enum ProjectTypes {
    INHOUSE, OUTSOURCED
}
